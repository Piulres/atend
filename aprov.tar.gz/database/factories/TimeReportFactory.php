<?php

$factory->define(App\TimeReport::class, function (Faker\Generator $faker) {
    return [

    ];
});
